package com.example.tansh.hospital01;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class Surgery extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_surgery);
    }
}
